#CASTSTATUS=$(avahi-browse -rt _googlecast._tcp | grep TV | grep txt | cut -d'"' -f 6 | cut -d'=' -f 2);
#CASTSTATUSA=$(avahi-browse -rt _googlecast._tcp | grep Audio | grep txt | cut -d'"' -f 6 | cut -d'=' -f 2);
KEY=$(echo "c4732c43f1a963fb05ae93b452d6467513dc31f908ba34d02ec7aa08f1bca62e:");
LIFX="https://api.lifx.com/v1/lights";

#colour
BULB0='d073d503aa58';
#white
BULB1='d073d511cf45';

curl -s -u "$KEY" "$LIFX/$BULB0" | egrep 'connected|power|brightness' | cut -d':' -f 2 | sed 's/\"//g' | tr -d ','| tr -d ' ' > /tmp/HBULB0
curl -s -u "$KEY" "$LIFX/$BULB1" | egrep 'connected|power|brightness' | cut -d':' -f 2 | sed 's/\"//g' | tr -d ','| tr -d ' ' > /tmp/HBULB1

BS0=$(cat /tmp/HBULB0 | sed -n '1p');
BP0=$(cat /tmp/HBULB0 | sed -n '2p');
BB0=$(cat /tmp/HBULB0 | sed -n '3p');

BS1=$(cat /tmp/HBULB1 | sed -n '1p');
BP1=$(cat /tmp/HBULB1 | sed -n '2p');
BB1=$(cat /tmp/HBULB1 | sed -n '3p');


THERM=$(curl -v -L -H "Authorization: Bearer c.k0QctDgC1YHmqN0k9PKzyyAXbLsCaGK3KwLvCpRn4qKStQbRxDMkuuaho5S3SaBNKzIxbTNEgJDLoDQ9hGuQQh3QpEpy7LdDygsQm5CvYcUbfeYGrP9V1BBoLG0kfi0m92JtFqPNxKZ763EI" -X GET "https://developer-api.nest.com/devices/thermostats/Zdr1gKRNYTEAJJqvkac0FHgLrvOl9uFW" | JSON.sh -l | grep hvac_state | cut -d']' -f 2 | sed 's/\"//g'
)

PROTECT=$(curl -v -L -H "Authorization: Bearer c.puLazmNMJjqdAKa18uDVvZYLvX9swGq5HgPWPwA7qE7sajiOZUTbShp9595cqF7o6fdFZCpPxDBX50RFBFhD6ktIy0RwEQFlKwX9Uq69vnxoMYdJ6DUYIcKD22DKrLu33vhDGHeq8BuGyVxW" -X GET "https://developer-api.nest.com/devices/" | JSON.sh -l | grep smoke_alarm_state | cut -d']' -f 2 | sed 's/\"//g');

TIME=$(date);

echo "

<html>
<body>

<head>

<title>Home</title>
<link rel='stylesheet' href='../styles.css'>

</head>
<body>

<h1>Home</h1>
<p>$TIME</p>
<h2>Nest</h2>
Protect: $PROTECT <div class='circle protect $PROTECT'></div>
<br>Thermostat: $THERM <div class='circle therm $THERM'><span></span></div>

<h2>LIFX</h2>
Living Room: $BS0 $BP0 $BB0 <div class='circle bulb $BS0 $BP0' style='opacity:$BB0'></div><br>
Dining room: $BS1 $BP1 $BB1 <div class='circle bulb $BS1 $BP1' style='opacity:$BB1'></div><br>



<h2>Chromecast</h2>

Chromecast: <div class='circle cc state$CASTSTATUS'><span></span></div>

Chromecast Audio: <div class='circle cc state$CASTSTATUSA'><span></span></div>




</body>

</html>
" > home/index.html
