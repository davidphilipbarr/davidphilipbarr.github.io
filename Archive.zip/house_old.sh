#CASTSTATUS=$(avahi-browse -rt _googlecast._tcp | grep TV | grep txt | cut -d'"' -f 6 | cut -d'=' -f 2);
#CASTSTATUSA=$(avahi-browse -rt _googlecast._tcp | grep Audio | grep txt | cut -d'"' -f 6 | cut -d'=' -f 2);
KEY=$(echo "c4732c43f1a963fb05ae93b452d6467513dc31f908ba34d02ec7aa08f1bca62e:");
LIFX="https://api.lifx.com/v1/lights";

#colour
BULB0='d073d503aa58';
#white
BULB1='d073d511cf45';

curl -s -u "$KEY" "$LIFX/$BULB0" | egrep 'connected|power|brightness' | cut -d':' -f 2 | sed 's/\"//g' | tr -d ','| tr -d ' ' > /tmp/HBULB0
curl -s -u "$KEY" "$LIFX/$BULB1" | egrep 'connected|power|brightness' | cut -d':' -f 2 | sed 's/\"//g' | tr -d ','| tr -d ' ' > /tmp/HBULB1

BS0=$(cat /tmp/HBULB0 | sed -n '1p');
BP0=$(cat /tmp/HBULB0 | sed -n '2p');
BB0=$(cat /tmp/HBULB0 | sed -n '3p');

BS1=$(cat /tmp/HBULB1 | sed -n '1p');
BP1=$(cat /tmp/HBULB1 | sed -n '2p');
BB1=$(cat /tmp/HBULB1 | sed -n '3p');


THERM=$(curl -v -L -H "Authorization: Bearer c.k0QctDgC1YHmqN0k9PKzyyAXbLsCaGK3KwLvCpRn4qKStQbRxDMkuuaho5S3SaBNKzIxbTNEgJDLoDQ9hGuQQh3QpEpy7LdDygsQm5CvYcUbfeYGrP9V1BBoLG0kfi0m92JtFqPNxKZ763EI" -X GET "https://developer-api.nest.com/devices/thermostats/Zdr1gKRNYTEAJJqvkac0FHgLrvOl9uFW" | JSON.sh -l | grep hvac_state | cut -d']' -f 2 | sed 's/\"//g'
)

PROTECT=$(curl -v -L -H "Authorization: Bearer c.puLazmNMJjqdAKa18uDVvZYLvX9swGq5HgPWPwA7qE7sajiOZUTbShp9595cqF7o6fdFZCpPxDBX50RFBFhD6ktIy0RwEQFlKwX9Uq69vnxoMYdJ6DUYIcKD22DKrLu33vhDGHeq8BuGyVxW" -X GET "https://developer-api.nest.com/devices/" | JSON.sh -l | grep smoke_alarm_state | cut -d']' -f 2 | sed 's/\"//g');

TIME=$(date);

echo "

<html>
<body>

<head>

<title>Home</title>

<style>

body {
background: #00BCD4;
font-family: 'Sans Serif';
color: #fff;
font-size: .9em
}

h1, h2{
padding: 0;
margin: 20px 0 5px 0
}

span {
border-radius: 50%;
width:40px;
height:40px;
display:block;
box-shadow: 0 0 10px rgba(0,0,0,0.3);
background: #9E9E9E;
}

span.cs0 {
background: #D32F2F;
}

span.cs1 {


background: #4CAF50
}

span.bulb.true.on{
background: #fff;
box-shadow: 0 0 10px rgba(255,255,255,1);
}

span.therm.heating {

background: #E64A19;
border: 3px solid #ccc;
width:36px;
height:36px
}
span.therm.off {
background: #455A64;
border: 3px solid #ccc;
width:36px;
height:36px
}

span.protect.ok {
background: #fff;
box-shadow: 0 0 10px #8BC34A;
}

</style>

</head>
<body>

<h1>Home</h1>
<p>$TIME</p>
<h2>Nest</h2>
Protect: $PROTECT <span class='protect$PROTECT'></span>
<br>Thermostat: $THERM <span class='therm$THERM'></span>
<h2>LIFX</h2>
Living Room: $BS0 $BP0 $BB0 <span class='bulb $BS0 $BP0' style='opacity:$BB0'></span><br>Dining room: $BS1 $BP1 $BB1<span class='bulb $BS1 $BP1' style='opacity:$BB1'></span><br>
<!--
<h2>Chromecast</h2>
Chromecast: $CASTSTATUS <span class='cs$CASTSTATUS'></span><br> Chromecast Audio: $CASTSTATUSA <span class='cs$CASTSTATUSA'></span>
-->

</body>

</html>
" > home/index.html
